## Install
To install the dependencies:

    npm install

For error related to express (Cannot find module 'express'):

    npm install express


## Start Server
To start the server:

    npm start

## Example
Run following example commands for each of the questions:<br>

    http://localhost:8081/task-1/I/want/title/?address=www.google.com.pk
    http://localhost:8081/task-2/I/want/title/?address=www.google.com.pk&address=www.twitter.com
    http://localhost:8081/task-3/I/want/title/?address=www.google.com.pk&address=www.twitter.com


